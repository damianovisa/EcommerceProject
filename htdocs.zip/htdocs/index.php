<?php
	require("app/core/init.php");
	new app\core\App();