<?php 
namespace app\models;

class User extends \app\core\Model{

	public function get($username){
		$SQL = "SELECT * FROM user WHERE user_email=:user_email";
		$STMT = self::$_connection->prepare($SQL);
		$STMT->execute(['username'=>$user_email]);
		$STMT->setFetchMode(\PDO::FETCH_CLASS, 'app\models\User');
		return $STMT->fetch();
	}
}